package com.vadantu.app.dao;

import com.vadantu.app.model.Order;

public interface OrderDao {

	Long save(Order order);

}
