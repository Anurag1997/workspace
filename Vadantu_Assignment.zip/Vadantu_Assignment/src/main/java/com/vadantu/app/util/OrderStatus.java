package com.vadantu.app.util;

public enum OrderStatus {

	NEW, HOLD, SHIPPED, DELIVERED, CLOSED;

}
